// Package zk provides Instancer and Registrar implementations for ZooKeeper.
package zk
