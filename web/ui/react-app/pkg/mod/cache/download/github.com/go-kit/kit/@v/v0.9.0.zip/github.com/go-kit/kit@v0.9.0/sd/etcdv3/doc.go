// Package etcdv3 provides an Instancer and Registrar implementation for etcd v3. If
// you use etcd v3 as your service discovery system, this package will help you
// implement the registration and client-side load balancing patterns.
package etcdv3
