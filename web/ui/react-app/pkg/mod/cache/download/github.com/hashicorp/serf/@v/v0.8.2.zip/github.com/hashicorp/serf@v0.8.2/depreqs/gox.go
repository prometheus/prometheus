package depreqs

import (
	"github.com/mitchellh/gox"
)

func main() {
	_, _ = gox.GoVersion()
}
