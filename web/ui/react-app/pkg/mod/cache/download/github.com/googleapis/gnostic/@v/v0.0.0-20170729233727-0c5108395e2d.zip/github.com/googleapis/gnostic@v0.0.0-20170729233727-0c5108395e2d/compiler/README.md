# Compiler support code

This directory contains compiler support code used by Gnostic and Gnostic extensions.