// Package dnssrv provides an Instancer implementation for DNS SRV records.
package dnssrv
