---
name: Feature Request
about: Request new features for the Go SDK.
---

### Feature Request

<!--
To help us better serve you, describe the feature you'd like and how it will help you.

Note that this is for SDK specific features. For Service API feature requests, use https://github.com/Azure/azure-rest-api-specs.
-->
